LABELS = {
    'GET': 'Retrieve',
    'PATCH': 'Update',
    'POST': 'Create',
    'DELETE': 'Delete',
}
